import java.util.Arrays;

/*Hue Ahnn
 * November 1, 2022
 * Practice using the split method from the String class to parse Strings
 */
public class Split {

	public static String removeSpaces(String filling) {
		String noSpaces = "";
		int space = filling.indexOf(" ");
		if (space == -1) {
			noSpaces = filling;
		}
		else {
			String[] sandwichFilling = filling.split(" ");
			for (int i = 0; i < sandwichFilling.length; i++) {
				noSpaces += sandwichFilling[i];
			}
		}
		return noSpaces;
	}
	public static String filling(String ingredients) {
		String filling = "";
		if (ingredients.equals("breadbread")) {
			return filling;
		}
		else {
			int start = ingredients.indexOf("bread");
			if (start == -1) {
				filling = "not a sandwich";
			}
			else {
				String sandwich = ingredients.substring(start);
				String sandwichMinusBread = sandwich.substring(5);
				int numBread = sandwichMinusBread.indexOf("bread");
				if (numBread == -1) {
					filling = "not a sandwich";
				}
				else {
					String fancySandwich = sandwichMinusBread.substring(numBread+5);
					int moreBread = fancySandwich.indexOf("bread");
					String[] notBread = sandwich.split("bread");
					filling = notBread[1];
					if (moreBread > -1) {
						filling += notBread[2];
					}
				}
			}
		}
		if (filling.equals("not a sandwich")) {
			return filling;
		}
		else {
			filling = removeSpaces(filling);
			return filling;
		}
	}
	public static void main(String[] args) {
//		// Your task Part 0
//		//String.split();
//		//It's a method that acts on a string, <StringName>.split(<sp>);
//		//Where sp is the string where the string splits
//		//And it returns an array
//		String[] ex1 = "I like apples!".split(" ");
//		System.out.println(Arrays.toString(ex1));
//		// it will split at spaces and return an array of ["I","like","apples!"]
//		String[] ex2 = "I really like really red apples!".split("really");
//		System.out.println(Arrays.toString(ex2));
//		// it will split at the word "really" and return an array of ["I "," like ","red apples!"]
//		//play around with String.split!
//		String[] ex2a = "I reallyreally likeapples".split("really");
//		System.out.println(Arrays.toString(ex2a));

		//Your task Part 1:
		/*Write a method that take in a string like
		* "applespineapplesbreadlettucetomatobaconmayohambreadcheese"
		* describing a sandwich.
		* Use String.split to split up the sandwich by the word "bread" and return what's in the middle of
		* the sandwich and ignores what's on the outside
		* What if it's a fancy sandwich with multiple pieces of bread?
		*/
		
		System.out.println(filling("applespineapplesbreadmayohambreadcheese"));
	    System.out.println(filling("breadmayobread"));
	    System.out.println(filling("applesbreadmayobread"));
	    System.out.println(filling("breadhambreadcheese"));
	    System.out.println(filling("breadbread"));
	    System.out.println(filling("breadcheese"));
	    System.out.println(filling("hamcheesebread"));
	    System.out.println(filling("cheese"));
	    System.out.println(filling("breadcheesebreadhambread"));
	    System.out.println(filling("hambreadmayobaconbreadavocadobread"));
		
		//Your task pt 2:
		/*Write a method that take in a string like
		* "apples pineapples bread lettuce tomato bacon mayo ham bread cheese"
		* describing a sandwich
		* use String.split to split up the sandwich at the spaces, " ", and return what's in the middle of
		* the sandwich and ignores what's on the outside.
		*The output for the example above should be lettucetomatobaconmayoham
		* You should call the method from part one in order to increase your reuse of code and reduce
		*the complexity of part 2.
		*/
	    System.out.println(filling("apples bread mayo bread"));
	    System.out.println(filling("bread ham bread cheese"));
	    System.out.println(filling("bread bread"));
	    System.out.println(filling("bread cheese"));
	    System.out.println(filling("ham bread mayo bacon bread avocado bread"));

		}
}
