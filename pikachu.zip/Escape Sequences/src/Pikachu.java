/* @author Hue Ahnn
 * @version August 23, 2022
 * Prints Pikachu using characters and escape sequences
 */
public class Pikachu {

	public static void main(String[] args) {
		System.out.println("\tPikachu welcomes you to the world of Pokemon!");
		System.out.println("\t\t\t\t(\\__/)");
		System.out.println("\t\t\t\t(o^.^)");
		System.out.println("\t\t\t      z(_(\")(\")");

	}

}
