import java.util.ArrayList;

/*Hue Ahnn
 * December 8, 2022
 * Country class will contain all of the info about a country:
 * its name, series name, years and data for the series
 * It will also be able to calculate and return information about the 
 * country */
public class Country {

	private String name;
	private String series;
	private ArrayList<Integer> years;
	private ArrayList<Double> data;
	
	//Constructor
	public Country(String name, String series, ArrayList<Integer> years, ArrayList<Double> data) {
		this.name = name;
		this.series = series;
		this.years = years;
		this.data = data;
	}
	
//prints all the pertinent information about a country, nicely formatted
	public String toString() {
		String output="";
		for (int i=0; i < years.size();i++) {
			output +=years.get(i)+"\t";
		}
		output +="\n";
		for (int i=0; i < data.size();i++) {
			double value =Math.round(data.get(i)*100.0)/100.0;
			output +=value+"\t";
		}
		output +="\nThis is the \""+series+"\" for "+name+"\n";
		output +="Minimum: "+min()+"\n"+"Maximum: "+max();
		output+="\n";
		return output;
	}
	
	//Calculate and returns the smallest data value
	public double min() {
		double min = data.get(0);
		for (int i=1; i<data.size();i++) {
			double data = this.data.get(i);
			if (data< min) 
				min = data;
		}
		return min;

	}
	
	//Calculate and returns the largest data value
	public double max() {
		double max = data.get(0);
		for (int i=1; i<data.size();i++) {
			double data = this.data.get(i);
			if (data> max) 
				max = data;
		}
		return max;
	}
	
	//	This method returns the units for the stored data.  
	//  The string that is returned should not include parentheses.  
	//  In the example above, a call to getUnits would return:  % of 
	//  population.
	public String getUnits() {
		String units;
		if (series.indexOf("(") == -1) {
			units = "";
		}
		else {
			units = series.substring(series.indexOf("(") + 1,series.indexOf(")"));
		}
		return units;
	}

	//	This method returns an acronym made of the first letter in each of the words in the series name, but excludes: of, in, the, at, to, by, per, on, a, an.  The acronym should be in ALL CAPS and should not include the units.  
	//	In the example above, a call to getAcronym would shorten the data series name Access to electricity to simply return: AE.  (If you�re using something like GDP that is already an acronym, it might help for testing to 
	//  adjust your data file to read �Gross domestic product�.)  
	public String getAcronym() {
		String acronym = "";
		String str = "";
		if(series.indexOf("(") == -1) {
			str = series;
		}
		else {
			str = series.substring(0,series.indexOf("("));
		}
		String[] remove = {"of", "in", "the", "at", "to", "by", "per", "on", "a", "an"};
		String[] arr = str.split(" ");
		for (int i = 0; i < arr.length; i++) {
			boolean takeOut = true;
			for (int j = 0; j < remove.length; j++) {
				if (arr[i].equalsIgnoreCase(remove[j])) {
					takeOut = false;
				}
			}
			if (takeOut) {
				String charToString = "";
				charToString += arr[i].charAt(0);
				acronym += (charToString.toUpperCase());
			}
		}
		return acronym;
	}

	//This method returns  �up�, �down�, or �no trend� depending on 
	//which direction the data is trending.  This method must call 
	//the private methods trendsUp and trendsDown.	
	public String getTrend() {
		if (trendsUp() == true) {
			return "up";
		}
		else if (trendsDown() == true) {
			return "down";
		}
		else return "no trend";
	}

	//	This method returns a boolean representing whether each 
	//  data point is higher than the previous one.  For example, 
	//  the method would return true if the data values were:  
	//  20, 22, 25, 27, 33.  The method would return false if the
	//  data values were:  20, 22, 22, 22, 25, 33.  (Yes, this is 
	//  a gross simplification of something that would be better 
	//  done with regression, but I don�t think anyone is up for 
	//  programming that right now.  Wait� are you?)   ;)
	private boolean trendsUp() {
		for (int i = 1; i < data.size(); i++) {
			if (data.get(i) <= data.get(i-1)) {
				return false;
			}
		}
		return true;
	}

/* 	Same idea as trendsUp� each data point must be lower than the 
 * one that came before, otherwise it will return false.
 */
	private boolean trendsDown() {
		for (int i = 1; i < data.size(); i++) {
			if (data.get(i) >= data.get(i-1)) {
				return false;
			}
		}
		return true;
	}
	// accepts a year and data point. adds these new data points to the end of the ArrayLists
	public void addDataPoint(int year, double newDatum) {
		this.years.add(year);
		this.data.add(newDatum);
	}
	//data value associated with the given year is changed to the given value
	public void editDataPoint(int year, double newDatum) {
		int index = years.indexOf(year);
		data.set(index,newDatum);
	}
	//returns the name of the country
	public String getCountry() {
		return name;
	}
	//returns the series of the data set, excluding the units
	public String getSeries() {
		return series.substring(0,series.indexOf("("));
	}
	//returns the arraylist of years for which the data is listed
	public ArrayList<Integer> getYears() {
		return years;
	}
	//returns an arraylist of the data
	public ArrayList<Double> getData() {
		return data;
	}
	//allows for the replacement of the series name
	public void setSeries(String s) {
		series = s;
	}
	//allows for the replacement of data values
	public void setData(ArrayList<Double> d) {
		data = d;
	}
}
