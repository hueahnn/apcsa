import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

//Denise Dreyer
//Client for the Country data project.  It will read form a file
//and analyze the data
//October 6, 2022
public class CountryClientCP1 {
	
	public static void main(String[] args) throws FileNotFoundException{
		File inputFile =new File("singleCountryData.txt");
		Scanner input = new Scanner(inputFile);
		String series = input.nextLine();
		int count = input.nextInt();
		String output="";
		for (int i=0; i<count;i++) {
			String year = input.next();
			output+=year+"\t";
		}
		output+="\n"+input.nextLine();
		System.out.println("\n"+output+"\n");
		String country =input.nextLine();
		for (int i=0; i<count;i++) {
			double data = input.nextDouble();
			output+=data+"\t";
		}
		System.out.println("\n"+output+"\n");
		System.out.println("This is the \""+series+"\" for "+country);
		input.close();//last line in the main method 
	}
}


