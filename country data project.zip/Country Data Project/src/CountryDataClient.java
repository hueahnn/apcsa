import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class CountryDataClient {
	//removes the given country from the arraylist of countries 
	public static void removeByName(ArrayList<Country> countries, String name) {
		for (int i = 0; i < countries.size(); i++) {
			if ((countries.get(i)).getCountry().equalsIgnoreCase(name)) {
				countries.remove(i);
			}
		}
	}
	//removes all country objects that have no trend in data
	public static void removeNoTrend(ArrayList<Country> countries) {
		for (int i = 0; i < countries.size(); i++) {
			if(countries.get(i).getTrend().equalsIgnoreCase("no trend")) {
				countries.remove(i);
				i--;
			}
		}
	}
	//removes all country objects that have the inputed trend. throws an exception if the inputed trend is not up, down, or no trend
	public static ArrayList<String> getListBasedOnTrend(ArrayList<Country> countries, String trendType)throws IllegalArgumentException{
		if(!trendType.equals("up") && !trendType.equals("down") &&!trendType.equals("no trend")) throw new IllegalArgumentException();
		ArrayList<String> newList = new ArrayList<String>();
		for (Country country:countries) {
				if(country.getTrend().equalsIgnoreCase(trendType)) {
					newList.add(country.getCountry());
				}
			}
		return newList;
	}
	
	public static void main(String[] args) throws FileNotFoundException{
		File inputFile = new File("CountryDataSet.csv");
		Scanner input = new Scanner(inputFile);
		String line = input.nextLine();
		String[] splitLine = line.split(",");
		String series = splitLine[0];
//		String[] splitSeries = series.split(" ");
		line = input.nextLine();
		splitLine = line.split(",");
		int count = splitLine.length-1;
		ArrayList<Integer> years = new ArrayList<Integer>();
		for (int i = 0;i < count; i++) {
			years.add(i,Integer.parseInt(splitLine[i+1]));
		}
//		System.out.println(splitSeries[0].substring(0,1) + splitSeries[1].substring(0,1).toUpperCase()+splitSeries[2].substring(0,1).toUpperCase()+ " for " + years.get(0) + "-" + years.get(years.size() - 1));
		System.out.println();
		ArrayList<Double> values = new ArrayList<Double>();
		ArrayList<Country> countries = new ArrayList<Country>();
		while (input.hasNextLine()) {
			line = input.nextLine();
			if(line.charAt(0) == '"') {
				String name = line.substring(1, line.lastIndexOf('"'));
				line = name.substring(name.indexOf(',') + 2) + " " + name.substring(0, name.indexOf(',')) + name.substring(name.lastIndexOf(','));
			}
			splitLine = line.split(",");
			String countryName = splitLine[0];
			values.clear();
			for (int i = 0; i < count; i++) {
				values.add(Double.parseDouble(splitLine[i+1]));
			}
			Country myCountry = new Country(countryName, series, years, values);
			countries.add(myCountry);
			System.out.println(myCountry);
//			System.out.println(myCountry.getAcronym());
			System.out.println(myCountry.getSeries());

		}
		input.close(); 
	}
}
