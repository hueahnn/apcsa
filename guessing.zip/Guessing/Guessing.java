//Hue Ahnn
//September 27, 2022
//Program that allows user to guess numbers in a given range until guessed correctly. Gives feedback on number if not guessed correctly.
import java.util.*;

public class Guessing 
{

	public static int getRandomNumber(int low, int high)
	{
		// Math.random() returns a decimal in the range [0, 1)
		// Pick a low and high value and test this out.  Can the 
		// computer choose the low and high bounds as its number?
		int rand = (int) (Math.random() * (high - low + 1)) + low;
		return rand;
	}
	
	public static String compareToSecret(int guessedNum, int secretNum)
	{
		String guessIs = "";
		if (guessedNum < secretNum)
			guessIs = "low";
		else
			guessIs = "high";
		return guessIs;
	}
	
	public static boolean inRange(int low, int high, int num)
	{
		if (low <= num && num <= high)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static void main(String[] args) 
	{
		Scanner userGuess = new Scanner(System.in);
		System.out.println("Hello! What is your name?");
		String name = userGuess.nextLine();
		System.out.println("Hello " + name + ". What range of numbers?\nMin? ");
		String low = userGuess.next();
		int lowest = Integer.parseInt(low);
		System.out.println("Max?");
		String high = userGuess.next();
		int highest = Integer.parseInt(high);
		if (lowest > highest) {
			throw new IllegalArgumentException("invalid range");
		}
		int secret = getRandomNumber(lowest, highest);
		int guess = -12345678;
		System.out.println("Guess a number in the range: ");
		while(secret != guess) {
			String num = userGuess.next();
			guess = Integer.parseInt(num);
			if (guess == secret) {
				System.out.println("You guessed right!");
				System.out.println("My number was " + secret + "!");
			}
			else {
				if (guess < lowest || guess > highest) {
					System.out.println("Invalid guess: out of range.");
				}
				else {
					String lowHigh = compareToSecret(guess, secret);
					System.out.println("Nope. " + guess + " is too " + lowHigh);
				}
				System.out.println("Guess again!");
			}
		}
		userGuess.close();
	}

}
