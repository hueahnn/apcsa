//Hue Ahnn
//September 22, 2022
//Class of methods needed to describe a quadratic.
public class Quadratic {

	//returns useful and significant features of a quadratic   
	public static String quadDescriber (double num1, double num2, double num3) {
		   int a = (int)num1;
		   int b = (int)num2;
		   int c = (int)num3;
		   String output = "Description of the graph of:\ny = " + num1 + " x^2 + " + num2 + " x + " + num3 + "\n";
		   if (num1 < 0) {
			   output += "\nOpens: Down";
		   }
		   else {
			   output += "\nOpens: Up";
		   }
		   output += "\nAxis of Symmetry: " + lineOfSymmetry(a,b,c);
		   output += "\nVertex: " + vertex(a,b,c);
		   output += "\nx-intercept(s): " + xInts(a,b,c);
		   output += "\ny-intercept: " + num3;
		   
		   return output;
	   }
	   //returns the discriminant of numbers a, b, and c
	   public static double discriminant(double a, double b, double c)	{
			return b * b - 4 * a * c;
		}
	   //returns the absolute value of the number entered
	   public static double absValue(double num)	{
			if (num >= 0)	{
				return num;
			}
			else {
				return 0 - num;
			}
		}
	   //returns the greater value of two numbers
	   public static double max(double num1, double num2) {
			if (num1 >= num2) {
				return num1;
			}
			else {
				return num2;
			}
		}
	   //rounds a double to 2 decimal places
	   public static double round2(double num) {
			double number = absValue(num);
			number += 0.005;
			number *= 100;
			int x = (int)number;
			number = x * 1.0 / 100;
			if (num < 0) {
				number = 0 - number;
			}
			return number;
		}
	   //returns the square root of the input number rounded to two decimal places
	   public static double sqrt(double num)	{
			if (num < 0)	{
				throw new IllegalArgumentException("input must be non-negative");
			}
			double guess = num / 2;
			double x;
			do {
				x = guess;
				guess = (x + (num / x)) / 2;
			}
			while(absValue(guess * guess - num) > 0.001);
			guess = round2(guess);
			return guess;
		}
	   //approximates the real root(s) of a quadratic equation in standard form
	   public static String quadForm(int a, int b, int c) {
			String finalRoots = "";
			if (discriminant(a,b,c) < 0)	{
				finalRoots = "no real roots";
			}
			else {
				double root1;
				root1 = (-b + sqrt(discriminant(a,b,c))) / 2 * a;
				root1 = round2(root1);
				double root2;
				root2 = (-b - sqrt(discriminant(a,b,c))) / 2 * a;
				root2 = round2(root2);
				if (discriminant(a,b,c) == 0)	{
					double root = 1.0 * -b / (2 * a);
					finalRoots += root;
				}
				else {
					double larger = max(root1,root2);
					if (root1 == larger)	{
						finalRoots += root2 + " and " + root1;
					}
					else {
						finalRoots += root1 + " and " + root2;
					}
				}
			}
			return finalRoots;
	   }
	   //returns the line of symmetry of a quadratic
	   public static double lineOfSymmetry(int a, int b, int c) {
		   double x = (-b) / (2.0 * a);
		   return x;
	   }
	   //returns the vertex of a quadratic
	   public static String vertex(int a, int b, int c) {
		   double x = lineOfSymmetry(a,b,c);
		   double y = a * (x * x) + b * x + c;
		   String vertexPoint = "(" + x + ", " + y + ")";
		   return vertexPoint;
	   }
	   //returns the x-intercepts of a quadratic
	   public static String xInts(int a, int b, int c)	{
		   String xIntercepts = quadForm(a,b,c);
		   if (xIntercepts.equals("no real roots")) {
			   xIntercepts = "";
		   }
		   return xIntercepts;
	   }

}
