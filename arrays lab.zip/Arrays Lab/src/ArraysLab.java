import java.util.Arrays;

/* Hue Ahnn
 * array methods
 * 10/27/2022
 * Create a class named ArraysLab that contains 6 static methods (main plus the 5 methods defined below).
 */
public class ArraysLab {
	
	public static int[] sum(int[] arr1, int[] arr2) {
		int[] array = new int[arr1.length];
		for (int i = 0; i < array.length; i++) {
			array[i] = arr1[i] + arr2[i];
		}
		return array;
	}
	
	public static int[] append(int[] arr, int num) {
		int[] array = new int[arr.length+1];
		for (int i = 0; i < arr.length; i++) {
			array[i] = arr[i];
		}
		array[array.length - 1] = num;
		return array;
	}
	public static int[] remove(int[] arr, int idx) {
		int[] array = new int[arr.length - 1];
		int count = 0; 
		for (int i = 0; i < array.length; i ++) {
			if (i != idx) {
				array[i] = arr[count];
				count++;
			}
			else {
				array[i] = arr[count + 1];
				count +=2;
			}
		}
		return array;
	}
	public static int sumEven(int[] arr) {
		int sum = 0;
		for (int i = 0; i < arr.length; i += 2) {
			sum += arr[i];
		}
		return sum;
	}
	public static void rotateRight(int[] arr) {
		int temp = arr[arr.length - 1];
		for (int i = arr.length -1 ; i > 0; i--) {
			arr[i] = arr[i - 1];
		}
		arr[0] = temp;
	}

	public static void main(String[] args) {
		int[] a1 = {5, 10, 15, 20, 25, 30, 35, 40};
		int[] a2 = {7, 14, 21, 28, 35, 42, 49, 56};
		int[] sumArr = sum(a1, a2);
		int appendNum = 200;
		int[] appendArr = append(a1, appendNum);
		int removeldx = 5;
		int[] removeArr = remove(a2, removeldx);
		int sumOfEvens = sumEven(appendArr);
		rotateRight(a1);
		
		System.out.println(Arrays.toString(sumArr));
		System.out.println(Arrays.toString(appendArr));
		System.out.println(Arrays.toString(removeArr));
		System.out.println(sumOfEvens);
		System.out.println(Arrays.toString(a1));
		
	}

}
