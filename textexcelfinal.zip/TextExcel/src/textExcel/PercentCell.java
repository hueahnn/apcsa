package textExcel;
/**
 * Hue Ahnn
 *March 16, 2023
 */
//extension of RealCell
public class PercentCell extends RealCell{
	//field that stores the percent
	private String percent;
	//constructor that calls the super and assigns a value into the field
	public PercentCell(String percent) {
		super(percent);
		this.percent = percent;
	}
	//returns a whole value truncation of the percent, including the percent symbol
	public String abbreviatedCellText() {
		String abrText = percent.substring(0, percent.indexOf(".")) + "%                    ";
		return abrText.substring(0, 10);
	}
	//returns a decimal equivalence of the percentage and removes the percent symbol
	public String fullCellText() {
		double newPercent = Double.parseDouble(percent.substring(0, percent.length() -1));
		newPercent /= 100;
		return newPercent + "";
	}
	//returns the full percent, excluding the percent symbol
	public double getDoubleValue() {
		return Double.parseDouble(fullCellText()) * 100;
	}
}
