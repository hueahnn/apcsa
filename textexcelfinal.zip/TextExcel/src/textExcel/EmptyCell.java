package textExcel;
//Hue Ahnn
//February 23, 2023
public class EmptyCell implements Cell {
	//constructor for empty cell
	public EmptyCell() {
	}
	//returns 10 spaces
	public String abbreviatedCellText() {
		return "          ";
	}
	//returns empty String
	public String fullCellText() {
		return "";
	}
}
