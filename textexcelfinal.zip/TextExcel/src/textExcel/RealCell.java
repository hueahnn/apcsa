/**
 * Hue Ahnn
 *March 16, 2023
 */
package textExcel;
public class RealCell implements Cell {
	//field that stores a String
	private String number;
	//constructor for RealCell that assigns a value to the field
	public RealCell(String number) {
		this.number = number;
	}
	//returns the value truncated to 10 characters
	public String abbreviatedCellText() {
		String abrText = number + "                    ";
		return abrText.substring(0, 10);
	}
	//returns the full value
	public String fullCellText() {
		return number;
	}
	//parses and returns the String value as a double
	public double getDoubleValue() {
		return Double.parseDouble(number);
	}

}
