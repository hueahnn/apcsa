package textExcel;
// Hue Ahnn
//Feb 21, 2023
// Client Code

import java.io.FileNotFoundException;
import java.util.Scanner;

public class TextExcel{

	public static void main(String[] args){
		/* scanner
		 * generate spreadsheet
		 * print it out
		 * loop
		 * 		get a command
		 * 		process and do the command
		 * 		(print) result or updated spreadsheet
		 * until "quit"
		 */
		Scanner input = new Scanner(System.in);
		Spreadsheet one = new Spreadsheet();
		String commands = input.nextLine();
		while (!commands.equalsIgnoreCase("quit")) {
			System.out.println(one.processCommand(commands));
		}
//		TestsALL.Helper th = new TestsALL.Helper();
//		System.out.println(th.getText());
	}
}
