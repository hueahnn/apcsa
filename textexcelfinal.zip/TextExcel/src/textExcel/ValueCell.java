package textExcel;
/**
 * Hue Ahnn
 *March 16, 2023
 */
public class ValueCell extends RealCell{
	//constructor for ValueCell
	public ValueCell(String number) {
		super(number);
	}
	//returns the value of the cell truncated to 10 characters
	public String abbreviatedCellText() {
		String abrText = getDoubleValue() + "                    ";
		return abrText.substring(0, 10);
	}
	//returns the entire value entered in by the user
	public String fullCellText() {
		return super.fullCellText();
	}
	//invokes the super method of getDoubleValue() in the RealCell class to parse and return a String as a double value
	public double getDoubleValue() {
		return super.getDoubleValue();
	}
}
