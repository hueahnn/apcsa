package textExcel;
//Hue Ahnn
//Defines a spreadsheet class for TextExcel
//March 14, 2023

public class TextCell implements Cell {
	//field that stores the phrase entered by the user excluding quotation marks
	private String text;
	//constructor for TextCell that excludes any quotation marks around the inputted String
	public TextCell(String text) {
		this.text = text.substring(1, text.length() - 1);
	}
	//text for spreadsheet cell display, must be exactly length 10
	public String abbreviatedCellText() {
		String abrText = text + "             ";
		return abrText.substring(0,10);
	}
	//text for individual cell inspection, not truncated or padded
	public String fullCellText() {
		return "\"" + text + "\"";
	}
}
