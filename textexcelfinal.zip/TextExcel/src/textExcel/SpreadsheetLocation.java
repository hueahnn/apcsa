package textExcel;

//Hue Ahnn
//Feb 21, 2023

public class SpreadsheetLocation implements Location{
	//field: contains the cell name (ex A1, B8)
	private String cellName;
	//constructor that takes in a cell name
	public SpreadsheetLocation(String cellName){
		this.cellName = cellName;
	}
	//converts the number passed in through the cell name into the row index for the array representation of the spreadsheet
    public int getRow(){
        return Integer.parseInt(cellName.substring(1)) - 1;
    }
    //converts the letter passed in through the cell name into the column index for the array representation of the spreadsheet
    public int getCol(){
        return Character.toUpperCase(cellName.charAt(0)) - 'A';
    }
}
