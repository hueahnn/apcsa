package textExcel;

//Hue Ahnn
//Defines a spreadsheet class for TextExcel
//Feb 21, 2023

public class Spreadsheet implements Grid{
	//field: 2d array that represents the spreadsheet.
	private Cell[][] spread = new Cell[getCols()][getRows()];
	//constructor for Spreadsheet
	public Spreadsheet(){
		makeEmpty();
	}
	//helper method that assigns EmptyCells to the entire spreadsheet
	public void makeEmpty() {
		for (int col = 0; col < getCols(); col++) {
			for (int row = 0; row < getRows(); row++) {
				spread[col][row] = new EmptyCell();
			}
		}
	}
	//takes in user input and performs actions based on what the user is asking for. uses if statements to filter out the different tasks
	public String processCommand(String command){
		//split on spaces
		//get for length of 1
		//	cell? --> print the cell's value
		//	clear? --> make all emptyCells
		//for length of 2
		//	get cell location
		//	make that cell empty
		String output = "";
		String[] commands = command.split(" " , 3);
		if (commands.length == 1) {
			//clears the whole spreadsheet
			if (commands[0].equalsIgnoreCase("clear")) {
				makeEmpty();
				output = getGridText();
			}
			//returns the full text in a cell
			else {
				SpreadsheetLocation loc = new SpreadsheetLocation(command);
				Cell a = spread[loc.getCol()][loc.getRow()];
				output = a.fullCellText();
			}
		}
		else {
			//empties a specific cell
			if (commands[0].equalsIgnoreCase("clear")) {
				SpreadsheetLocation loc = new SpreadsheetLocation(commands[1]);
				spread[loc.getCol()][loc.getRow()] = new EmptyCell();
				output = getGridText();
			}
			//assigns values to cells
			else if (commands[1].equalsIgnoreCase("=")) {
				SpreadsheetLocation loc = new SpreadsheetLocation(commands[0]);
				//percent cells
				if (commands[2].charAt(commands[2].length()-1) == '%'){
					spread[loc.getCol()][loc.getRow()] = new PercentCell(commands[2]);
				}
				//text cells
				else if (commands[2].charAt(0) == '\"') {
					spread[loc.getCol()][loc.getRow()] = new TextCell(commands[2]);
				}
				//formula cells
				else if (commands[2].charAt(0) == '(') {
					spread[loc.getCol()][loc.getRow()] = new FormulaCell(commands[2], this);
				}
				//all other input (value cells)
				else {
					spread[loc.getCol()][loc.getRow()] = new ValueCell(commands[2]);
				}
				output = getGridText();
			}
		}
		return output;
	}
	//returns the number of rows (20)
	public int getRows(){
		return 20;
	}
	//returns the number for columns (12)
	public int getCols(){
		return 12;
	}
	//returns the cell at a particular location in the spreadsheet using the location
	public Cell getCell(Location loc){
		return spread[loc.getCol()][loc.getRow()];
	}
	//returns the cell at a particular location in the spreadsheet using the column and row number
	public Cell getCell(int col, int row) {
		return spread[col][row];
	}
	//returns a String representation of the entire spreadsheet, include the row and columns, and truncated all values in cells at 10 spaces
	//formatted with spaces, bars, and values consistently throughout the whole spreadsheet
	public String getGridText(){
		String formatted = "   ";
		int count = 65;
		for (int i = 0; i < getCols(); i++) {
			formatted += "|" + Character.toString(count) + "         ";
			count++;
		}
		formatted += "|\n";
		count = 1;
		for (int i = 0; i < getRows(); i++) {
			if (count < 10) {
				formatted += count + "  |";
				count++;
			}
			else {
				formatted += count + " |";
				count++;
			}
			for (int j = 0; j < getCols(); j++) {
				formatted += spread[j][i].abbreviatedCellText() + "|";
			}
			formatted += "\n";
		}
		return formatted;
	}

}
