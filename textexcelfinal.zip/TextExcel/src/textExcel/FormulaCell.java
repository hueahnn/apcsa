/**
 * Hue Ahnn
 *March 16, 2023
 */
package textExcel;
//extension of RealCell
public class FormulaCell extends RealCell{
	//field: spreadsheet object
	private Spreadsheet sheet;
	//constructor for FormulaCell that includes parameters for the formula String and the spreadsheet that it is in
	public FormulaCell(String formula, Spreadsheet spread) {
		super(formula.substring(2, formula.length()));
		this.sheet = spread;
	}
	//returns the formula truncated to 10 characters and without parentheses
	public String abbreviatedCellText() {
		return ("" + getDoubleValue()+ "             ").substring(0, 10);
	}
	//returns the entire formula with parentheses around it
	public String fullCellText() {
		return "( " + super.fullCellText();
	}
	//helper method that calculates the sum and/or average of all the values in a given range
	public double sumAvg(String[] numbers) {
		String[] cellReferences = numbers[1].split("-");
		Location upperLeft = new SpreadsheetLocation(cellReferences[0]);
		Location bottomRight = new SpreadsheetLocation(cellReferences[1]);
		double runningSum = 0;
		int count = 0;
		for (int cols = upperLeft.getCol(); cols <= bottomRight.getCol(); cols++) {
			for (int rows = upperLeft.getRow(); rows <= bottomRight.getRow(); rows++) {
				RealCell a = (RealCell) sheet.getCell(cols,rows);
				runningSum += a.getDoubleValue();
				count++;
			}
		}
		if (numbers[0].toUpperCase().contains("SUM")) { 
			return runningSum;
		}
		else {
			return runningSum/count;
		}
	}
	//helper method that returns the numerical value being processed
	//if a cell reference is passed in, returns the value stored in the cell
	//if a number is passed in, parses the String into a double
	public double getValue(String i) {
		if (Character.isLetter(i.charAt(0))) {
			Location loc = new SpreadsheetLocation(i);
			return ((RealCell)(sheet.getCell(loc))).getDoubleValue();
		}
		else {
			return Double.parseDouble(i);
		}
	}
	//returns the double value of the formula solved
	public double getDoubleValue() {
		String[] numbers = super.fullCellText().split(" ");
		//calculates the sum or average by calling a helper method
		if (numbers[0].toUpperCase().contains("SUM") || numbers[0].toUpperCase().contains("AVG")) {
			return sumAvg(numbers);
		}
		//takes care of the first value, so the rest of the array can be processed in pairs
		double answer = getValue(numbers[0]);
		for (int i = 1; i < numbers.length; i += 2) {
			//isolates the operation to figure out what operation to do
			String operation = numbers[i];
			if (operation.equals("+")) {
				answer += getValue(numbers[i + 1]);
			}
			else if (operation.equals("-")) {
				answer -= getValue(numbers[i + 1]);
			}
			else if (operation.equals("*")) {
				answer *= getValue(numbers[i + 1]);
			}
			else if (operation.equals("/")) {
				answer /= getValue(numbers[i + 1]);
			}
		}
		return answer;
	}
}
